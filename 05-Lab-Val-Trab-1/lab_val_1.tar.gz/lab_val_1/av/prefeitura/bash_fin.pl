#!/usr/bin/perl

system("rm /var/www/html/index.lighttpd.html");
system("cp /opt/prefeitura/var/www/html/index.html /var/www/html/index.html");

while (1) {
   system("clear");
   system("figlet 'acesso restrito'");
   $tmp = <STDIN>;
}

