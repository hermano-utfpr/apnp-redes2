#!/usr/bin/perl

system("cp /opt/dnsparana/etc/bind/named.conf.local /etc/bind/named.conf.local");
system("cp /opt/dnsparana/var/cache/bind/db.prefeitura /var/cache/bind/db.prefeitura");
system("/etc/init.d/bind9 restart");

