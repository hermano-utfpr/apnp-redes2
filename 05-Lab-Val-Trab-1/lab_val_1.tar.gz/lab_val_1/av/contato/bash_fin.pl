#!/usr/bin/perl

use strict;

while (1) {

   system("clear");
   system("figlet 'contato'");

   print "\n\n";
   print "_nomecontato_: Olá _nomeadmin_!\n";
   print "_nomecontato_: Precisamos que você arrume o endereço IP do nosso site.\n";
   print "_nomecontato_: Agora www._prefeitura_.pr.gov.br deve resolver para: _ipserver_.\n";
   print "_nomecontato_: Vou fazer um teste aqui ...\n\n";

   system("rm /tmp/saida.txt 2> /dev/null");
   system("wget www._prefeitura_.pr.gov.br -O /tmp/saida.txt 2> /dev/null");
   sleep(3);
   my $encontrou = 0;
   open (SAIDA, "/tmp/saida.txt");
   while (my $l = <SAIDA>) {
      if ($l =~ /_PREFEITURA_/) {
         $encontrou = 1;
      }
   } 
   close (SAIDA); 

   if (!($encontrou)) {

      print "_nomecontato_: Infelizmente o acesso não funcionou! :(\n";

   } else {

      print "_nomecontato_: Funcionou! Grata! :)\n";
      print "                                       _\n";
      print "                                      / |       \n";
      print "                                   __ \\ :  ____ \n";
      print "                                 (____)  ` \\    \n";
      print "                                (____)|   |     \n";
      print "                                 (____).__|     \n";
      print "                                  (___)__. /___ \n";
   }

   print "\n";
   print "Tecle [ENTER] para testar novamente.\n";
   <STDIN>;

}

