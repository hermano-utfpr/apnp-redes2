#!/usr/bin/perl

while (1) {

   system("clear");
   system("figlet 'acesso restrito'");

   <STDIN>;

}


