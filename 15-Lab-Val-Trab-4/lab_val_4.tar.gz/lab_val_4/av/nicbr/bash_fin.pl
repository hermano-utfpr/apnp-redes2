#!/usr/bin/perl

print ("\nPreparando ...\n");
sleep (2);

while (1) {

   system("clear");
   system("figlet 'Nic.BR'");

   print "\n";
   print "_nomecontato_: Olá _nomeadmin_!\n";
   print "_nomecontato_: O domínio _seldominio_.com.br está registrado na Nic.BR\n";
   print "_nomecontato_: com os seguintes servidores DNS de autoridade:\n";
   print "_nomecontato_: ns1._seldominio_.com.br com o endereço _ipns1_ e\n";
   print "_nomecontato_: ns2._seldominio_.com.br com o endereço _ipns2_.\n\n";
   sleep(3);
   print "_nomecontato_: Vou fazer um teste aqui para verificar o seu domínio ...\n";
   sleep(3);

   $certo = 0;

   # Primeiro teste
   
   print "\n_nomecontato_: Consultando autoridades em _ipns1_ ...\n";
   sleep(3);

   my @res = qx/dig \@_ipns1_ _seldominio_.com.br NS/;
   $answer = 0;
   $additional = 0;
   @dom = ();
   @ips = ();
   for (my $i = 0; $i < scalar(@res); $i++) {

      if ($answer) {
         if ($res[$i] =~ /IN\s+NS/) {
            @campos = split(/\s+/,$res[$i]);
            push(@dom,$campos[4]);
            print "-> ".$campos[4]."\n";
         } else {
            $answer = 0;
         }
      }
      if ($additional) {
         if ($res[$i] =~ /IN\s+A/) {
            @campos = split(/\s+/,$res[$i]);
            push(@ips,$campos[4]);
            print "-> ".$campos[4]."\n";
         } else {
            $additional = 0;
         }
      }
      if ($res[$i] =~ /ANSWER SECTION/) {
         $answer = 1;
      }
      if ($res[$i] =~ /ADDITIONAL SECTION/) {
         $additional = 1;
      }

   } 
  
   if (scalar(@dom) == 2 && scalar(@ips) == 2) {
      if (($ips[0] eq "_ipns1_" && $ips[1] eq "_ipns2_") || ($ips[0] eq "_ipns2_" && $ips[1] eq "_ipns1_")) {
         $certo ++;
      }
   }

   print "\n_nomecontato_: Consultando autoridades em _ipns2_ ...\n";
   sleep(3);

   # Segundo teste

   my @res = qx/dig \@_ipns2_ _seldominio_.com.br NS/;
   $answer = 0;
   $additional = 0;
   @dom = ();
   @ips = ();
   for (my $i = 0; $i < scalar(@res); $i++) {

      if ($answer) {
         if ($res[$i] =~ /IN\s+NS/) {
            @campos = split(/\s+/,$res[$i]);
            push(@dom,$campos[4]);
            print "-> ".$campos[4]."\n";
         } else {
            $answer = 0;
         }
      }
      if ($additional) {
         if ($res[$i] =~ /IN\s+A/) {
            @campos = split(/\s+/,$res[$i]);
            push(@ips,$campos[4]);
            print "-> ".$campos[4]."\n";
         } else {
            $additional = 0;
         }
      }
      if ($res[$i] =~ /ANSWER SECTION/) {
         $answer = 1;
      }
      if ($res[$i] =~ /ADDITIONAL SECTION/) {
         $additional = 1;
      }

   } 
  
   if (scalar(@dom) == 2 && scalar(@ips) == 2) {
      if (($ips[0] eq "_ipns1_" && $ips[1] eq "_ipns2_") || ($ips[0] eq "_ipns2_" && $ips[1] eq "_ipns1_")) {
         $certo ++;
      }
   }
   sleep(3);

   if ($certo == 2) {
      print "\n_nomecontato_: Resolvido! Grata!\n";
      print "                                       _\n";
      print "                                      / |       \n";
      print "                                   __ \\ :  ____ \n";
      print "                                 (____)  ` \\    \n";
      print "                                (____)|   |     \n";
      print "                                 (____).__|     \n";
      print "                                  (___)__. /___ \n";
   } else {
      print "\n_nomecontato_: Configurações estão incompletas ou não funcionaram! :/\n";
      print "_nomecontato_: Favor verificar!!!\n";
   }

   print "\n_nomecontato_: Tecle [Enter] para testar novamente!\n";
   <STDIN>;

}




