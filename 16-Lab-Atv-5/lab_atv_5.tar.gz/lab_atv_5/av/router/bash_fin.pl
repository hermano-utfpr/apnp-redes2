#!/usr/bin/perl

system("cp /opt/router/etc/quagga/* /etc/quagga/");
system("/etc/init.d/quagga restart");
system("chmod 755 /opt/router/bin/*");
system("cp /opt/router/bin/* /bin/");

print "\n";
print "Para configurar o router digite: zebra\n";
print "Para configurar o ospf digite..: ospfd\n\n";

