#!/usr/bin/perl

system("dpkg --install /opt/web/pkg/*.deb");
system("/etc/init.d/apache2 restart");

