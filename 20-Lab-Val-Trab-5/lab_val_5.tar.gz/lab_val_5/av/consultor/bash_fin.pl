#!/usr/bin/perl

use strict;
use Net::Telnet;
use Net::IMAP::Simple;

print ("\nPreparando ...\n");
sleep (80);

my $nomecontato = ucfirst("_nomecontato_");
my $mailcontato = "_nomecontato_\@_seldominio_.com";

my $nomeadmin = ucfirst("_nomeadmin_");
my $mailadmin = "_nomeadmin_\@_seldominio_.com";

my $contador = 1;

my $senha = 'srz'.int(rand(1000));

while (1) {

   my $num1 = int(rand(10000000));
   my $num2 = int(rand(10000000));

   system("clear");
   system("figlet '$nomecontato'");

   print "\n";
   print "$nomecontato: Alô $nomeadmin!\n";
   print "$nomecontato: Preciso que você crie minha conta de e-mail:\n";
   print "$nomecontato: $mailcontato e senha \"$senha\".\n";
   print "$nomecontato: Vou mandar um e-mail para você ($mailadmin) ...\n";

   my $falhas = 0;
   my $t = new Net::Telnet (Timeout => 20, Host => 'mail._seldominio_.com', Port => 25, Prompt => '/./') or $falhas = 1;
   $t->open() or $falhas = 1;
   my $cmd = "ehlo _seldominio_.com\n";
   $cmd .= "mail from: $mailcontato\n";
   $cmd .= "rcpt to: $mailadmin\n";
   $cmd .= "data\n";
   $cmd .= "From: $mailcontato\n";
   $cmd .= "To: $mailadmin\n";
   $cmd .= "Subject: Teste $contador!\n\n";
   $cmd .= "Ola $nomeadmin,\n\n";
   $cmd .= "Se voce esta lendo aqui entao recebeu o e-mail com sucesso!\n";
   $cmd .= "Responda este e-mail com o resultado da soma: $num1 + $num2.\n\n";
   $cmd .= "Obrigado :)\n\n";
   $cmd .= "$nomecontato\n";
   $cmd .= "\n\n.\n\nquit\n\n";
   $t->cmd($cmd) or $falhas = 1;
   $t->close;

   if ($falhas == 0) {

      print "$nomecontato: ... Teste $contador foi enviado!\n\n";

      print "\n$nomecontato: Parece que deu certo, aguardo seu e-mail de resposta!\n";
      print "\n$nomecontato: Tecle [Enter] para continuar!\n";
      <STDIN>;

      $falhas = 0;
      my $mensagens = "";
      my $imap = Net::IMAP::Simple->new('imap._seldominio_.com');

      if(!$imap->login(lc($nomecontato),$senha)){
         $falhas = 1;
         print "\n$nomecontato: Falhou usuario e senha :(\n";
      } else {
         my $nm = $imap->select('INBOX');
         print "\n$nomecontato: Recebi $nm e-mails, verificando ...\n";
         for(my $i = 1; $i <= $nm; $i++){
            $mensagens .= $imap->get($i);
         }
      }

      $imap->quit;

      my $soma = $num1 + $num2;
 
      my $certo = 0;
      if ($mensagens =~ /$soma/) {
         $certo = 1; 
      }
 
      if ($falhas == 0 && $certo == 1) {
         print "\n$nomecontato: Resposta certa! Obrigado $nomeadmin!\n";
         print "                                       _\n";
         print "                                      / |       \n";
         print "                                   __ \\ :  ____ \n";
         print "                                 (____)  ` \\    \n";
         print "                                (____)|   |     \n";
         print "                                 (____).__|     \n";
         print "                                  (___)__. /___ \n";

         $falhas = 0;
         $t = new Net::Telnet (Timeout => 20, Host => 'mail._seldominio_.com', Port => 25, Prompt => '/./') or $falhas = 1;
         $t->open() or $falhas = 1;
         $cmd = "ehlo _seldominio_.com\n";
         $cmd .= "mail from: $mailcontato\n";
         $cmd .= "rcpt to: $mailadmin\n";
         $cmd .= "data\n";
         $cmd .= "From: $mailcontato\n";
         $cmd .= "To: $mailadmin\n";
         $cmd .= "Subject: Funcionou!\n\n";
         $cmd .= "Ola $nomeadmin,\n\n";
         $cmd .= "Resposta certa!\n\n";
         $cmd .= "Obrigado :)\n\n";
         $cmd .= "$nomecontato\n";
         $cmd .= "\n\n.\n\nquit\n\n";
         $t->cmd($cmd) or $falhas = 1;
         $t->close;
      } else {
         print "\n$nomecontato: Não recebi o seu e-mail com a resposta certa! :/\n";
         print "$nomecontato: Poderia verificar? Mandei com assunto: Teste $contador!\n";
      }

   } else {
      print "\n$nomecontato: Não consegui enviar o e-mail :/\n";
      print "$nomecontato: Algo deu errado, poderia verificar?\n";
   }

   $contador++;

   print "\n$nomecontato: Tecle [Enter] para testar novamente!\n";
   <STDIN>;

}







