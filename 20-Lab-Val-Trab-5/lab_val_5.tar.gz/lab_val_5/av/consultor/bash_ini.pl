#!/usr/bin/perl

system("dpkg --install /opt/consultor/libnet-telnet-perl_3.04-1_all.deb");
system("dpkg --install /opt/consultor/libnet-imap-simple-perl_1.2205-1_all.deb");

