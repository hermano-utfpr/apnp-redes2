#!/usr/bin/perl

use strict;

my $srv = "mail";

system("cp /opt/$srv/etc/postfix/* /etc/postfix/");
system("/etc/init.d/postfix restart");


