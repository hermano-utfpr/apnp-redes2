#!/usr/bin/perl

system("cp /opt/servidor1/etc/bind/* /etc/bind/");
system("/etc/init.d/bind9 restart");

while (1) {

   print ("\nPreparando ...\n");
   sleep (20);

   system("clear");
   system("figlet 'servidor1'");

   print "\n";
   print "_nomecontato_: Olá _nomeadmin_!\n";
   print "_nomecontato_: Você pode fazer consultas DNS no endereço IP _ips1_.\n";
   print "_nomecontato_: Primeira pergunta:\n";
   print "_nomecontato_: Qual é o endereço IP do servidor DNS autoritativo de _dominio_.com?\n";
   print "_nomecontato_: Digite a resposta logo abaixo e tecle [Enter]:\n\n";

   my $ip = <STDIN>;
   chomp($ip);
   print "\n";

   if (!($ip =~ /_ips3_/ig)) {

      print "_nomecontato_: Infelizmente você errou!\n";
      print "_nomecontato_: Recebeu reprovação! :/\n\n";

   } else {

      print "_nomecontato_: Muito bem! Agora a segunda pergunta:\n";
      print "_nomecontato_: Qual é o endereço IP do servidor que hospeda o site www._dominio_.com?\n";
      print "_nomecontato_: Digite a resposta logo abaixo e tecle [Enter]:\n\n";

      my $ip = <STDIN>;
      chomp($ip);
      print "\n";

      if (!($ip =~ /_ips2_/ig)) {

         print "_nomecontato_: Infelizmente você errou!\n";
         print "_nomecontato_: Recebeu reprovação! :/\n\n";

      } else {

         print "_nomecontato_: Muito bem! Agora a terceira e última pergunta:\n";
         print "_nomecontato_: Qual é o endereço IP do servidor que hospeda o site _dominio_.com?\n";
         print "_nomecontato_: Digite a resposta logo abaixo e tecle [Enter]:\n\n";

         my $ip = <STDIN>;
         chomp($ip);
         print "\n";

         if (!($ip =~ /_ips4_/ig)) {

            print "_nomecontato_: Infelizmente você errou!\n";
            print "_nomecontato_: Recebeu reprovação! :/\n\n";

         } else {

            print "_nomecontato_: Resolveu! Recebeu aprovação!\n";
            print "                                       _\n";
            print "                                      / |       \n";
            print "                                   __ \\ :  ____ \n";
            print "                                 (____)  ` \\    \n";
            print "                                (____)|   |     \n";
            print "                                 (____).__|     \n";
            print "                                  (___)__. /___ \n";

         }

      }
      
   }

   print "\n";

   while (1) { sleep(100); }
}




