#!/usr/bin/perl

use strict;

system("cp /opt/servidor4/var/www/html/* /var/www/html/");

while (1) {

   system("clear");
   system("figlet 'acesso restrito'");

   <STDIN>;

}


