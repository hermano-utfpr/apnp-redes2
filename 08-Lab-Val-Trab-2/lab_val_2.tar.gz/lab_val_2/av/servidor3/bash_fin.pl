#!/usr/bin/perl

use strict;

system("cp /opt/servidor3/etc/bind/* /etc/bind/");
system("cp /opt/servidor3/var/cache/bind/* /var/cache/bind/");
system("/etc/init.d/bind9 restart");

while (1) {

   system("clear");
   system("figlet 'acesso restrito'");

   <STDIN>;

}


