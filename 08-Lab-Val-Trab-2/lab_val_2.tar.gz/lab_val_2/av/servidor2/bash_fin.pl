#!/usr/bin/perl

use strict;

system("cp /opt/servidor2/var/www/html/* /var/www/html/");

while (1) {

   system("clear");
   system("figlet 'acesso restrito'");

   <STDIN>;

}


