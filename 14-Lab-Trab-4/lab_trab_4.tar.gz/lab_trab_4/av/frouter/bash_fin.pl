#!/usr/bin/perl

system("cp /opt/frouter/etc/quagga/* /etc/quagga/");
system("/etc/init.d/quagga restart");
system("chmod 755 /opt/frouter/bin/*");
system("cp /opt/frouter/bin/* /bin/");

print "\n";
print "Para configurar o router digite: zebra\n";
print "Para configurar o rip    digite: ripd\n";
print "Para configurar o ospf   digite: ospfd\n\n";

