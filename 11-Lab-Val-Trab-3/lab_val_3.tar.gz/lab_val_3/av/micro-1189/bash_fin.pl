#!/usr/bin/perl

use strict;

while (1) {

   system("clear");
   system("figlet '_nomecontato_'");

   print "\n\n";
   print "_nomecontato_: Olá _nomeadmin_!\n";
   print "_nomecontato_: Eu recebi um micro para as minhas atividades e percebi\n";
   print "_nomecontato_: que não tem resolução do DNS reverso.\n";
   print "_nomecontato_: Poderia arrumar? \n";
   print "_nomecontato_: O nome da máquina é _micro2_ e o IP é _ipm2_.\n";
   print "\nTecle [Enter] para continuar!\n";
   <STDIN>;

   print "_nomecontato_: Vou fazer um teste ... \n\n";

   system("rm /tmp/saida.txt 2> /dev/null");
   system("host _ipm2_ > /tmp/saida.txt");
   my $encontrou_rev = 0;
   open (SAIDA, "/tmp/saida.txt");
   while (my $l = <SAIDA>) {
      if ($l =~ /_micro2_._dominio_.intranet/i) {
         $encontrou_rev = 1;
      }
   } 
   close (SAIDA); 

   sleep(3);

   if ($encontrou_rev) {

      print "_nomecontato_: Legal, a resolução reversa funcionou!\n";
      print "\n";
      print "_nomecontato_: _nomeadmin_, mais uma coisa ...\n";
      print "_nomecontato_: Poderia colocar o site http://_subdominio_._dominio_.intranet no ar\n";
      print "_nomecontato_: e colocar um aviso no conteúdo?\n";
      print "_nomecontato_: Escreva assim: \"Este site esta em construcao. Favor aguardar!\".\n";
      print "\nTecle [Enter] para continuar!\n";
      <STDIN>;

      print "_nomecontato_: Vou tentar acessar o site ... \n\n";

      system("rm /tmp/saida.txt 2> /dev/null");
      system("wget http://_subdominio_._dominio_.intranet -O /tmp/saida.txt 2> /dev/null");
      my $encontrou = 0;
      open (SAIDA, "/tmp/saida.txt");
      while (my $l = <SAIDA>) {
         if ($l =~ /Favor aguardar/i) {
            $encontrou = 1;
         }
      } 
      close (SAIDA); 

      system("rm /tmp/saida.txt 2> /dev/null");
      system("wget http://www._dominio_.intranet -O /tmp/saida.txt 2> /dev/null");
      my $encontrou_erro = 0;
      open (SAIDA, "/tmp/saida.txt");
      while (my $l = <SAIDA>) {
         if ($l =~ /Favor aguardar/i) {
            $encontrou_erro = 1;
         }
      } 
      close (SAIDA); 

      sleep(3);

      if (!($encontrou)) {

         print "_nomecontato_: Infelizmente o acesso não funcionou,\n";
         print "_nomecontato_: ou o aviso não está conforme eu pedi. :(\n";

      } elsif ($encontrou_erro) {

         print "_nomecontato_: Calma aí ... :/\n";
         print "_nomecontato_: Você modificou o site http://www._dominio_.intranet?\n";
         print "_nomecontato_: Favor, verifique se ocorreu algum erro.\n";

      } else {

         print "_nomecontato_: Funcionou! Muito obrigado _nomeadmin_! :)\n";
         print "                                       _\n";
         print "                                      / |       \n";
         print "                                   __ \\ :  ____ \n";
         print "                                 (____)  ` \\    \n";
         print "                                (____)|   |     \n";
         print "                                 (____).__|     \n";
         print "                                  (___)__. /___ \n";
      }

   } else {

         print "_nomecontato_: Infelizmente a resolução reversa não funcionou.\n";
         print "_nomecontato_: Poderia verificar? :(\n";

   }

   print "\n";
   print "Tecle [ENTER] para testar novamente.\n";
   <STDIN>;

}


