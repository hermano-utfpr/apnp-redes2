#!/usr/bin/perl

use strict;

system("cp /opt/servidor-dns/etc/bind/* /etc/bind/");
system("cp /opt/servidor-dns/var/cache/bind/* /var/cache/bind/");
system("/etc/init.d/bind9 restart");


