#!/usr/bin/perl

use strict;

system("cp /opt/servidor-web/etc/apache2/sites-available/* /etc/apache2/sites-available/");
system("cp /opt/servidor-web/var/www/html/* /var/www/html/");
system("/etc/init.d/apache2 restart");


