#!/usr/bin/perl

use strict;

my $srv = "router";

system("cp /opt/$srv/etc/dhcp/dhcpd.conf /etc/dhcp/");
system("/etc/init.d/isc-dhcp-server restart");

system("cp /opt/$srv/etc/quagga/* /etc/quagga/");
system("/etc/init.d/quagga restart");
system("chmod 755 /opt/$srv/bin/*");
system("cp /opt/$srv/bin/* /bin/");

print "\n";
print "Para configurar o router digite: zebra\n";
print "Para configurar o ospf digite..: ospfd\n\n";

