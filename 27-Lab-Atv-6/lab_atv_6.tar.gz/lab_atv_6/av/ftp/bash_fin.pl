#!/usr/bin/perl

use strict;

my $pass = crypt("_senhaadmin_","password");
system("useradd -m -p $pass _nomeadmin_ -s /bin/bash");
system("passwd -d estudante");

system("mv /opt/ftp/figs/ /home/_nomeadmin_/");
system("chown -R _nomeadmin_._nomeadmin_ /home/_nomeadmin_/");


