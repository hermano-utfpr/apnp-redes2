#!/usr/bin/perl

# perl dominio.com 2 outro.com 3 aindaoutro.com 4

open (ARQ, ">db.com");
print ARQ "\$ORIGIN com.\n";
print ARQ "\$TTL 60;\n";
print ARQ "\@ IN SOA root root (1 60 60 60 60);\n";
print ARQ "\@ IN NS root\n";
print ARQ "root IN A 200.1.2.10\n\n";
for ($i = 0; $i < scalar(@ARGV); $i += 2) {
   print ARQ $ARGV[$i]." IN NS dns.".$ARGV[$i]."\n";
   print ARQ "dns.".$ARGV[$i]." IN A 200.".$ARGV[$i+1].".2.10\n\n";
}
close (ARQ);

open (ARQ, ">db.200");
print ARQ "\$ORIGIN 200.in-addr.arpa.\n";
print ARQ "\$TTL 60;\n";
print ARQ "\@ IN SOA root.com. root.com. (1 60 60 60 60);\n";
print ARQ "\@ IN NS root.com.\n\n";
for ($i = 0; $i < scalar(@ARGV); $i += 2) {
   print ARQ "0.".$ARGV[$i+1]." IN NS dns.".$ARGV[$i].".com.\n";
   print ARQ "1.".$ARGV[$i+1]." IN NS dns.".$ARGV[$i].".com.\n";
   print ARQ "2.".$ARGV[$i+1]." IN NS dns.".$ARGV[$i].".com.\n";
}
close (ARQ);

for ($i = 0; $i < scalar(@ARGV); $i += 2) {
   print $ARGV[$i+1]." -> ".$ARGV[$i]."\n";
}

