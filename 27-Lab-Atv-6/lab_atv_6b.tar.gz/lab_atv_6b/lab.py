import os
import random
import re
import sys
import subprocess
import tkinter as tk
from PIL import Image, ImageTk

####################################################################

version = '2.9'
admin = ''
titulo = 'Laboratório de Segurança'
wan = ''
mac_wan = ''
so = ''
x = '0'
y1 = '0'
y2 = '1'
y3 = '2'
dominio = ''
senha = ''

# Verificar versao
lversion = os.popen('cat /etc/xbnet_version.txt').read().rstrip()
if (lversion != version):
   print ('Script deve ser executado em xbnet '+version+'! (local: xbnet '+lversion+')')
   sys.exit()

# Testar Root
if os.getuid() != 0:
   print('Script deve ser executado como root!')
   print('Tente: sudo py lab.py')
   sys.exit()

# Nome do Admin
try:
  admin = sys.argv[1]
  admin_ok = False
  if (len(admin) >= 3 and len(admin) <= 20):
     if re.match(r"^[A-Za-z]+$",admin):
        admin_ok = True
  if not (admin_ok):
     print ('Para o nome do Admin utilize:')
     print ('Mínimo de 3 e máximo de 20 caracteres')
     print ('Caracteres de "a" a "z"')
     sys.exit()
except Exception as e:
  print ('Faltou preencher o nome do Admin!')
  print ('Tente: py lab.py Fulano')
  sys.exit()

# SO para o Desktop
texto = 'Selecione um S.O. para o desktop!\n' \
        'Opções: reactos ou slitaz\n' \
        'Exemplo: py lab.py '+admin+' reactos' 
try:
  so = sys.argv[2]
  if not (so == 'reactos' or so == 'slitaz'):
     print (texto)
     sys.exit()
except Exception as e:
  print (texto)
  sys.exit()

# Interface de saída para WAN
texto = 'Selecione a interface de saída para WAN!\n' \
        'Encontre a interface com o comando "ifconfig"\n' \
        'Exemplo: py lab.py '+admin+' '+so+' enp3s0' 
try:
  wan = sys.argv[3]
  if not (len(wan) >= 3):
     print(texto)
     sys.exit()
except Exception as e:
  print(texto)
  sys.exit()

# Valor de X
texto = 'Digite um número X (inteiro par) para endereçamento!\n' \
        'Suas redes serão endereçadas da seguinte maneira:\n' \
        'WAN 200.0.0.X/24, LAN 200.X.'+y1+'.0/24 e DMZ 200.X.'+y2+'.0/24\n' \
        'Exemplo: py lab.py '+admin+' '+so+' '+wan+' 100' 
try:
  x = sys.argv[4]
  if not (int(x) >= 2 and int(x) <= 254):
     print(texto)
     sys.exit()
except Exception as e:
  print(texto)
  sys.exit()

# dominio
texto = 'Digite o seu domínio DNS!\n' \
        'Exemplo, para o domínio "site.com" digite: \n' \
        'py lab.py '+admin+' '+so+' '+wan+' '+x+' site.com' 
try:
  dominio = sys.argv[5]
  if not (len(dominio) >= 2 and len(dominio) <= 30):
     print(texto)
     sys.exit()
except Exception as e:
  print(texto)
  sys.exit()

# senha
texto = 'Digite uma senha alfanumérica para o usuario '+admin+':\n' \
        'Exemplo: \n' \
        'py lab.py '+admin+' '+so+' '+wan+' '+x+' '+dominio+' '+'def456'
try:
  senha = sys.argv[6]
  if not (len(senha) >= 5 and len(senha) <= 20 and senha.isalnum()):
     print(texto)
     sys.exit()
except Exception as e:
  print(texto)
  sys.exit()


# Enderecamento

y = '10'

ip_router_b1 = '1'
ip_router_b2 = '1'
ip_firewall_b1 = '1'
ip_firewall_b2 = '2'
ip_gateway_b1 = '1'
ip_dns_b1 = '10'
ip_web_b1 = str(random.randint(20,29))
ip_mail_b1 = str(random.randint(30,39))
ip_ftp_b1 = str(random.randint(40,49))
ip_sql_b1 = str(random.randint(50,59))
ip_notebook_b1 = str(random.randint(100,199))
ip_desktop_b1 = str(random.randint(200,254))

ip_router_e0 = '200.0.0.'+x
ip_router_e1 = '200.'+x+'.'+y2+'.1'
ip_router_e2 = '200.'+x+'.'+y1+'.1'
ip_router_e3 = '200.'+x+'.254.254'
ip_firewall_e0 = '200.'+x+'.'+y1+'.2'
ip_firewall_e1 = '200.'+x+'.'+y3+'.1'
ip_dns = '200.'+x+'.'+y3+'.10'
ip_ca = '200.'+x+'.'+y3+'.11' # temporario
ip_ca_b1 = '11' # temporario
ip_web = '200.'+x+'.'+y3+'.'+ip_web_b1
ip_mail = '200.'+x+'.'+y3+'.'+ip_mail_b1
ip_ftp = '200.'+x+'.'+y3+'.'+ip_ftp_b1
ip_sql = '200.'+x+'.'+y3+'.'+ip_sql_b1

ip_notebook = '200.'+x+'.'+y2+'.'+ip_notebook_b1
ip_desktop = '200.'+x+'.'+y2+'.'+ip_desktop_b1

ip_rede_dmz = '200.'+x+'.'+y3+'.0'
ip_rede_lan = '200.'+x+'.'+y2+'.0'
ip_rede_lnk = '200.'+x+'.'+y1+'.0'
ip_rev_lnk = y1+'.'+x+'.200'
ip_rev_lan = y2+'.'+x+'.200'
ip_rev_dmz = y3+'.'+x+'.200'

# MAC Randomico para WAN
mw1 = str(random.randint(0,9))
mw2 = str(random.randint(0,9))
mw3 = str(random.randint(0,9))
mw4 = str(random.randint(0,9))
mw5 = str(random.randint(0,9))
mw6 = str(random.randint(0,9))
mac_wan = (mw1+mw2+':'+mw3+mw4+':'+mw5+mw6)

###################################################################

switch_name = []
switch_prep = []
switch_load = []
switch_rect_x = []
switch_rect_y = []
switch_taps = []

uml_name = []
uml_prep = []
uml_load = []
uml_inst = []
uml_runrc = []
uml_rect_x = []
uml_rect_y = []
uml_kernel = []
uml_fs = []
uml_mem = []
uml_pkgs = []
uml_eths = []
uml_taps = []
uml_macs = []
uml_ips = []
uml_masks = []
uml_gw = []
uml_domain = []
uml_dns = []
uml_route = []
uml_cmds = []

vbox_name = []
vbox_appl = []
vbox_prep = []
vbox_load = []
vbox_rect_x = []
vbox_rect_y = []
vbox_tap = []
vbox_mac = []
vbox_rdp = []

wshark_name = []
wshark_iface = []
wshark_prep = []
wshark_load = []
wshark_rect_x = []
wshark_rect_y = []

rect_c_switch = []
rect_e_switch = []
rect_c_uml = []
rect_e_uml = []
rect_c_vbox = []
rect_e_vbox = []
rect_c_wshark = []
rect_e_wshark = []

####################################################################

# Switch WAN ########################
switch_name.append('switch-wan')
switch_prep.append(True)
switch_load.append(False)
switch_rect_x.append(255)
switch_rect_y.append(85)
swnic_tap = []
swnic_tap.append(wan)
swnic_tap.append('tap0')
switch_taps.append(swnic_tap)

# Switch LNK ########################
switch_name.append('switch-link')
switch_prep.append(True)
switch_load.append(False)
switch_rect_x.append(1200)
switch_rect_y.append(1200)
swnic_tap = []
swnic_tap.append(wan)
swnic_tap.append('tap1')
swnic_tap.append('tap2')
switch_taps.append(swnic_tap)

# Switch LNK2 ########################
switch_name.append('switch-link2')
switch_prep.append(True)
switch_load.append(False)
switch_rect_x.append(1201)
switch_rect_y.append(1201)
swnic_tap = []
swnic_tap.append(wan)
swnic_tap.append('tap3')
switch_taps.append(swnic_tap)

# Switch DMZ ########################
switch_name.append('switch-dmz')
switch_prep.append(True)
switch_load.append(False)
switch_rect_x.append(146)
switch_rect_y.append(393)
swnic_tap = []
swnic_tap.append(wan)
swnic_tap.append('tap10')
swnic_tap.append('tap11')
swnic_tap.append('tap12')
swnic_tap.append('tap13')
swnic_tap.append('tap14')
swnic_tap.append('tap15')
swnic_tap.append('tap16') # Mirror 
switch_taps.append(swnic_tap)

# Switch LAN ########################
switch_name.append('switch-lan')
switch_prep.append(True)
switch_load.append(False)
switch_rect_x.append(640)
switch_rect_y.append(85)
swnic_tap = []
swnic_tap.append('tap20')
swnic_tap.append('tap21')
swnic_tap.append('tap22')
swnic_tap.append('tap23')
swnic_tap.append('tap24')
swnic_tap.append('tap25')
switch_taps.append(swnic_tap)

# ROUTER ###########################
uml_name.append('router')
uml_prep.append(False)
uml_load.append(False)
uml_inst.append(True)
uml_runrc.append(True)
uml_rect_x.append(440)
uml_rect_y.append(85)
uml_kernel.append('linux_v4_nf_c')
uml_fs.append('jessie_fs')
uml_mem.append('64')
host_pkgs = []
host_pkgs.append('tcpdump')
host_pkgs.append('telnet')
host_pkgs.append('quagga')
#host_pkgs.append('iptraf')
host_pkgs.append('isc-dhcp-server')
uml_pkgs.append(host_pkgs)
host_eths = []
host_taps = []
host_macs = []
host_ips = []
host_masks = []
host_eths.append('eth0') #### eth0 com WAN
host_taps.append('tap0')
host_macs.append('00:9a:7e:'+mac_wan)
host_ips.append(ip_router_e0)
host_masks.append('255.255.255.0')
host_eths.append('eth1') #### eth1 com LAN
host_taps.append('tap20')
host_macs.append('00:9a:7e:01:00:00')
host_ips.append(ip_router_e1)
host_masks.append('255.255.255.0')
host_eths.append('eth2') #### eth2 com Link DMZ
host_taps.append('tap1')
host_macs.append('00:9a:7e:02:00:00')
host_ips.append(ip_router_e2)
host_masks.append('255.255.255.0')
host_eths.append('eth3') #### eth3 com Link 2
host_taps.append('tap3')
host_macs.append('00:9a:7e:03:00:00')
host_ips.append(ip_router_e3)
host_masks.append('255.255.0.0')
uml_eths.append(host_eths)
uml_taps.append(host_taps)
uml_macs.append(host_macs)
uml_ips.append(host_ips)
uml_masks.append(host_masks)
uml_gw.append('') #### route/dns
uml_domain.append(dominio)
uml_dns.append(ip_dns)
uml_route.append(True)
host_cmds = []
host_cmds.append('sed -i \'s/_iproutere0_/'+ip_router_e0+'/\' en/dn/router/etc/quagga/zebra.conf')
host_cmds.append('sed -i \'s/_iproutere1_/'+ip_router_e1+'/\' en/dn/router/etc/quagga/zebra.conf')
host_cmds.append('sed -i \'s/_iproutere2_/'+ip_router_e2+'/\' en/dn/router/etc/quagga/zebra.conf')
host_cmds.append('sed -i \'s/_iproutere3_/'+ip_router_e3+'/\' en/dn/router/etc/quagga/zebra.conf')
host_cmds.append('sed -i \'s/_iprededmz_/'+ip_rede_dmz+'/\' en/dn/router/etc/quagga/zebra.conf')
host_cmds.append('sed -i \'s/_ipfirewalle0_/'+ip_firewall_e0+'/\' en/dn/router/etc/quagga/zebra.conf')
host_cmds.append('sed -i \'s/_iprededmz_/'+ip_rede_dmz+'/\' en/dn/router/etc/quagga/ospfd.conf')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/router/etc/dhcp/dhcpd.conf')
host_cmds.append('sed -i \'s/_ipnet_/'+ip_rede_lan+'/g\' en/dn/router/etc/dhcp/dhcpd.conf')
host_cmds.append('sed -i \'s/_ipdns_/'+ip_dns+'/\' en/dn/router/etc/dhcp/dhcpd.conf')
host_cmds.append('sed -i \'s/_ipgateway_/'+ip_router_e1+'/\' en/dn/router/etc/dhcp/dhcpd.conf')
host_cmds.append('sed -i \'s/_ipdesktop_/'+ip_desktop+'/g\' en/dn/router/etc/dhcp/dhcpd.conf')
uml_cmds.append(host_cmds)

# FIREWALL ###########################
uml_name.append('firewall')
uml_prep.append(False)
uml_load.append(False)
uml_inst.append(True)
uml_runrc.append(True)
uml_rect_x.append(173)
uml_rect_y.append(189)
uml_kernel.append('linux_v4_nf_c')
uml_fs.append('jessie_fs')
uml_mem.append('64')
host_pkgs = []
host_pkgs.append('tcpdump')
host_pkgs.append('iptstate')
#host_pkgs.append('iptraf')
#host_pkgs.append('ngrep')
host_pkgs.append('telnet')
host_pkgs.append('quagga')
uml_pkgs.append(host_pkgs)
host_eths = []
host_taps = []
host_macs = []
host_ips = []
host_masks = []
host_eths.append('eth0') #### eth0 com Link Router
host_taps.append('tap2')
host_macs.append('00:fa:a1:00:00:01')
host_ips.append(ip_firewall_e0)
host_masks.append('255.255.255.0')
host_eths.append('eth1') #### eth1 com DMZ
host_taps.append('tap10')
host_macs.append('00:fa:a1:01:00:01')
host_ips.append(ip_firewall_e1)
host_masks.append('255.255.255.0')
uml_eths.append(host_eths)
uml_taps.append(host_taps)
uml_macs.append(host_macs)
uml_ips.append(host_ips)
uml_masks.append(host_masks)
uml_gw.append(ip_router_e2) #### route/dns
uml_domain.append(dominio)
uml_dns.append(ip_dns)
uml_route.append(True)
host_cmds = []
uml_cmds.append(host_cmds)

# DNS ###########################
uml_name.append('dns')
uml_prep.append(False)
uml_load.append(False)
uml_inst.append(True)
uml_runrc.append(True)
uml_rect_x.append(181)
uml_rect_y.append(508)
uml_kernel.append('linux_v4')
uml_fs.append('jessie_fs')
uml_mem.append('64')
host_pkgs = []
host_pkgs.append('tcpdump')
#host_pkgs.append('dnsutils')
host_pkgs.append('bind9')
host_pkgs.append('netcat')
host_pkgs.append('openssh-server')
uml_pkgs.append(host_pkgs)
host_eths = []
host_taps = []
host_macs = []
host_ips = []
host_masks = []
host_eths.append('eth0') #### eth0 
host_taps.append('tap11')
host_macs.append('00:da:e8:00:00:01')
host_ips.append(ip_dns)
host_masks.append('255.255.255.0')
uml_eths.append(host_eths)
uml_taps.append(host_taps)
uml_macs.append(host_macs)
uml_ips.append(host_ips)
uml_masks.append(host_masks)
uml_gw.append(ip_firewall_e1) #### route/dns
uml_domain.append(dominio)
uml_dns.append(ip_dns)
uml_route.append(False)
host_cmds = []
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/dns/etc/bind/named.conf.local')
host_cmds.append('sed -i \'s/_revlnk_/'+ip_rev_lnk+'/\' en/dn/dns/etc/bind/named.conf.local')
host_cmds.append('sed -i \'s/_revlan_/'+ip_rev_lan+'/\' en/dn/dns/etc/bind/named.conf.local')
host_cmds.append('sed -i \'s/_revdmz_/'+ip_rev_dmz+'/\' en/dn/dns/etc/bind/named.conf.local')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/g\' en/dn/dns/var/cache/bind/db.reverse.lnk')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/g\' en/dn/dns/var/cache/bind/db.reverse.lan')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/g\' en/dn/dns/var/cache/bind/db.reverse.dmz')
host_cmds.append('sed -i \'s/_iproutere0_/'+ip_router_e0+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_iproutere1_/'+ip_router_e1+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_iproutere2_/'+ip_router_e2+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_ipfirewalle0_/'+ip_firewall_e0+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_ipfirewalle1_/'+ip_firewall_e1+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_ipdns_/'+ip_dns+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_ipweb_/'+ip_web+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_ipmail_/'+ip_mail+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_ipftp_/'+ip_ftp+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_ipsql_/'+ip_sql+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_ipnotebook_/'+ip_notebook+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_ipdesktop_/'+ip_desktop+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_revdmz_/'+ip_rev_dmz+'/\' en/dn/dns/var/cache/bind/db.reverse.dmz')
host_cmds.append('sed -i \'s/_ipfirewallb1_/'+ip_firewall_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.dmz')
host_cmds.append('sed -i \'s/_ipdnsb1_/'+ip_dns_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.dmz')
host_cmds.append('sed -i \'s/_ipwebb1_/'+ip_web_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.dmz')
host_cmds.append('sed -i \'s/_ipmailb1_/'+ip_mail_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.dmz')
host_cmds.append('sed -i \'s/_ipftpb1_/'+ip_ftp_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.dmz')
host_cmds.append('sed -i \'s/_ipsqlb1_/'+ip_sql_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.dmz')
host_cmds.append('sed -i \'s/_revlnk_/'+ip_rev_lnk+'/\' en/dn/dns/var/cache/bind/db.reverse.lnk')
host_cmds.append('sed -i \'s/_iprouterb1_/'+ip_router_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.lnk')
host_cmds.append('sed -i \'s/_ipfirewallb2_/'+ip_firewall_b2+'/\' en/dn/dns/var/cache/bind/db.reverse.lnk')
host_cmds.append('sed -i \'s/_revlan_/'+ip_rev_lan+'/\' en/dn/dns/var/cache/bind/db.reverse.lan')
host_cmds.append('sed -i \'s/_iprouterb1_/'+ip_router_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.lan')
host_cmds.append('sed -i \'s/_ipnotebookb1_/'+ip_notebook_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.lan')
host_cmds.append('sed -i \'s/_ipdesktopb1_/'+ip_desktop_b1+'/\' en/dn/dns/var/cache/bind/db.reverse.lan')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/dns/bash_fin.pl')
host_cmds.append('sed -i \'s/_senhaadmin_/'+senha+'/\' en/dn/dns/bash_fin.pl')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/dns/var/cache/bind/db.principal')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/dns/var/cache/bind/db.reverse.dmz')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/dns/var/cache/bind/db.reverse.lan')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/dns/var/cache/bind/db.reverse.lnk')
uml_cmds.append(host_cmds)

# WEB ###########################
uml_name.append('web')
uml_prep.append(False)
uml_load.append(False)
uml_inst.append(True)
uml_runrc.append(True)
uml_rect_x.append(333)
uml_rect_y.append(508)
uml_kernel.append('linux_v4')
uml_fs.append('jessie_fs')
uml_mem.append('128')
host_pkgs = []
host_pkgs.append('tcpdump')
host_pkgs.append('apache2')
#host_pkgs.append('php5')
#host_pkgs.append('php5-mysql')
host_pkgs.append('netcat')
#host_pkgs.append('ftp')
host_pkgs.append('openssh-server')
uml_pkgs.append(host_pkgs)
host_eths = []
host_taps = []
host_macs = []
host_ips = []
host_masks = []
host_eths.append('eth0') #### eth0 
host_taps.append('tap12')
host_macs.append('00:da:e8:00:00:02')
host_ips.append(ip_web)
host_masks.append('255.255.255.0')
uml_eths.append(host_eths)
uml_taps.append(host_taps)
uml_macs.append(host_macs)
uml_ips.append(host_ips)
uml_masks.append(host_masks)
uml_gw.append(ip_firewall_e1) #### route/dns
uml_domain.append(dominio)
uml_dns.append(ip_dns)
uml_route.append(False)
host_cmds = []
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/web/var/www/html/index.html')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/web/var/www/html/app/connect-db.php')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/web/var/www/html/app/view.php')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/web/var/www/html/app/view-paginated.php')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/web/var/www/html/app/new.php')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/web/var/www/html/app/edit.php')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/web/var/www/html/index.html')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/web/bash_fin.pl')
host_cmds.append('sed -i \'s/_senhaadmin_/'+senha+'/\' en/dn/web/bash_fin.pl')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/g\' en/dn/web/etc/apache2/sites-available/000-default.conf')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/web/etc/apache2/sites-available/000-default.conf')
uml_cmds.append(host_cmds)

# MAIL ###########################
uml_name.append('mail')
uml_prep.append(False)
uml_load.append(False)
uml_inst.append(True)
uml_runrc.append(True)
uml_rect_x.append(500)
uml_rect_y.append(508)
uml_kernel.append('linux_v4')
uml_fs.append('jessie_fs')
uml_mem.append('128')
host_pkgs = []
host_pkgs.append('tcpdump')
host_pkgs.append('postfix')
host_pkgs.append('courier-pop')
#host_pkgs.append('courier-imap')
host_pkgs.append('netcat')
host_pkgs.append('openssh-server')
uml_pkgs.append(host_pkgs)
host_eths = []
host_taps = []
host_macs = []
host_ips = []
host_masks = []
host_eths.append('eth0') #### eth0 
host_taps.append('tap13')
host_macs.append('00:da:e8:00:00:03')
host_ips.append(ip_mail)
host_masks.append('255.255.255.0')
uml_eths.append(host_eths)
uml_taps.append(host_taps)
uml_macs.append(host_macs)
uml_ips.append(host_ips)
uml_masks.append(host_masks)
uml_gw.append(ip_firewall_e1) #### route/dns
uml_domain.append(dominio)
uml_dns.append(ip_dns)
uml_route.append(False)
host_cmds = []
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/mail/etc/postfix/main.cf')
host_cmds.append('sed -i \'s/_ipnetdmz_/'+ip_rede_dmz+'\/24'+'/\' en/dn/mail/etc/postfix/main.cf')
host_cmds.append('sed -i \'s/_ipnetlan_/'+ip_rede_lan+'\/24'+'/\' en/dn/mail/etc/postfix/main.cf')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/mail/bash_fin.pl')
host_cmds.append('sed -i \'s/_senhaadmin_/'+senha+'/\' en/dn/mail/bash_fin.pl')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/\' en/dn/mail/bash_fin.pl')
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.capitalize()+'/\' en/dn/mail/welcome.txt')
uml_cmds.append(host_cmds)

# FTP ###########################
uml_name.append('ftp')
uml_prep.append(False)
uml_load.append(False)
uml_inst.append(True)
uml_runrc.append(True)
uml_rect_x.append(660)
uml_rect_y.append(508)
uml_kernel.append('linux_v4')
uml_fs.append('jessie_fs')
uml_mem.append('64')
host_pkgs = []
host_pkgs.append('tcpdump')
host_pkgs.append('netcat')
host_pkgs.append('telnetd')
host_pkgs.append('tftpd')
host_pkgs.append('proftpd')
#host_pkgs.append('ftp')
uml_pkgs.append(host_pkgs)
host_eths = []
host_taps = []
host_macs = []
host_ips = []
host_masks = []
host_eths.append('eth0') #### eth0 
host_taps.append('tap14')
host_macs.append('00:da:e8:00:00:04')
host_ips.append(ip_ftp)
host_masks.append('255.255.255.0')
uml_eths.append(host_eths)
uml_taps.append(host_taps)
uml_macs.append(host_macs)
uml_ips.append(host_ips)
uml_masks.append(host_masks)
uml_gw.append(ip_firewall_e1) #### route/dns
uml_domain.append(dominio)
uml_dns.append(ip_dns)
uml_route.append(False)
host_cmds = []
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/ftp/bash_fin.pl')
host_cmds.append('sed -i \'s/_senhaadmin_/'+senha+'/\' en/dn/ftp/bash_fin.pl')
uml_cmds.append(host_cmds)

# SQL ###########################
uml_name.append('sql')
uml_prep.append(False)
uml_load.append(False)
uml_inst.append(True)
uml_runrc.append(True)
uml_rect_x.append(10000)
uml_rect_y.append(10000)
uml_kernel.append('linux_v4')
uml_fs.append('jessie_fs')
uml_mem.append('256')
host_pkgs = []
host_pkgs.append('tcpdump')
host_pkgs.append('netcat')
host_pkgs.append('openssh-server')
uml_pkgs.append(host_pkgs)
host_eths = []
host_taps = []
host_macs = []
host_ips = []
host_masks = []
host_eths.append('eth0') #### eth0 
host_taps.append('tap15')
host_macs.append('00:da:e8:00:00:05')
host_ips.append(ip_sql)
host_masks.append('255.255.255.0')
uml_eths.append(host_eths)
uml_taps.append(host_taps)
uml_macs.append(host_macs)
uml_ips.append(host_ips)
uml_masks.append(host_masks)
uml_gw.append(ip_firewall_e1) #### route/dns
uml_domain.append(dominio)
uml_dns.append(ip_dns)
uml_route.append(False)
host_cmds = []
host_cmds.append('sed -i \'s/_nomeadmin_/'+admin.lower()+'/\' en/dn/sql/bash_fin.pl')
host_cmds.append('sed -i \'s/_senhaadmin_/'+senha+'/\' en/dn/sql/bash_fin.pl')
host_cmds.append('sed -i \'s/_seldominio_/'+dominio+'/g\' en/dn/sql/opt/app.dump')
host_cmds.append('cp -r /opt/dpkg/mysql-server/ en/dn/sql/') # Problema mysql-server, solucao paliativa
uml_cmds.append(host_cmds)

# NOTEBOOK  ###########################
uml_name.append('notebook')
uml_prep.append(False)
uml_load.append(False)
uml_inst.append(True)
uml_runrc.append(True)
uml_rect_x.append(636)
uml_rect_y.append(230)
uml_kernel.append('linux_v4')
uml_fs.append('jessie_fs')
uml_mem.append('128')
host_pkgs = []
host_pkgs.append('tcpdump')
host_pkgs.append('telnet')
host_pkgs.append('dnsutils')
host_pkgs.append('links')
host_pkgs.append('lynx')
host_pkgs.append('nmap')
host_pkgs.append('ftp')
host_pkgs.append('lftp')
host_pkgs.append('tftp')
#host_pkgs.append('hping3')
host_pkgs.append('netcat')
#host_pkgs.append('mysql-client')
host_pkgs.append('openssh-client')
uml_pkgs.append(host_pkgs)
host_eths = []
host_taps = []
host_macs = []
host_ips = []
host_masks = []
host_eths.append('eth0') #### eth0 
host_taps.append('tap21')
host_macs.append('00:de:81:a0:00:02')
host_ips.append(ip_notebook)
host_masks.append('255.255.255.0')
uml_eths.append(host_eths)
uml_taps.append(host_taps)
uml_macs.append(host_macs)
uml_ips.append(host_ips)
uml_masks.append(host_masks)
uml_gw.append(ip_router_e1) #### route/dns
uml_domain.append(dominio)
uml_dns.append(ip_dns)
uml_route.append(False)
host_cmds = []
uml_cmds.append(host_cmds)

# DESKTOP #######################
vbox_name.append('desktop')
vbox_appl.append(so)
vbox_prep.append(False)
vbox_load.append(False)
vbox_rect_x.append(793)
vbox_rect_y.append(230)
vbox_tap.append('tap22')
vbox_mac.append('00:21:b0:c5:00:03')
vbox_rdp.append('50001')

# WireShark1 ##################
wshark_name.append('wireshark1')
wshark_iface.append('tap1')
wshark_prep.append(True)
wshark_load.append(False)
wshark_rect_x.append(343)
wshark_rect_y.append(188)

# WireShark2 ##################
wshark_name.append('wireshark2')
wshark_iface.append('tap20')
wshark_prep.append(True)
wshark_load.append(False)
wshark_rect_x.append(525)
wshark_rect_y.append(64)

# WireShark3 ##################
wshark_name.append('wireshark3')
wshark_iface.append('tap10')
wshark_prep.append(True)
wshark_load.append(False)
wshark_rect_x.append(151)
wshark_rect_y.append(277)

####################################################################

win_wid   = 900
win_hei   = 600
win_bg    = 'white'
win_img   = 'dt/lab.png'
win_rsz   = 12
win_rcd   = 'gray'
win_rce   = 'blue'
win_red   = 'red'
win_ree   = 'green'

win = tk.Tk()
win.title(titulo)
win_cnv = tk.Canvas(win, width=win_wid, height=win_hei, bg=win_bg)
win_cnv.pack()

im = Image.open(win_img)
im_tk = ImageTk.PhotoImage(im)

win_cnv.create_image(win_wid/2,win_hei/2,image=im_tk)

win_cnv.create_text(285,250,anchor=tk.W,font=('Helvetica',10),text='Admin: '+admin.capitalize())
win_cnv.create_text(285,265,anchor=tk.W,font=('Helvetica',10),text='Domain: '+dominio)
win_cnv.create_text(285,280,anchor=tk.W,font=('Helvetica',10),text='WAN: '+ip_router_e0+' via '+wan)
win_cnv.create_text(285,295,anchor=tk.W,font=('Helvetica',10),text='LAN: '+ip_rede_lan+'/24')
win_cnv.create_text(285,310,anchor=tk.W,font=('Helvetica',10),text='DMZ: '+ip_rede_dmz+'/24')

win_cnv.create_text(280,45,anchor=tk.W,font=('Helvetica',8),text=ip_router_e0)
win_cnv.create_text(319,93,anchor=tk.W,font=('Helvetica',8),text=ip_router_e2)
win_cnv.create_text(435,72,anchor=tk.W,font=('Helvetica',8),text=ip_router_e1)

win_cnv.create_text(174,167,anchor=tk.W,font=('Helvetica',8),text=ip_firewall_e0)
win_cnv.create_text(135,230,anchor=tk.W,font=('Helvetica',8),text=ip_firewall_e1)

win_cnv.create_text(118,570,anchor=tk.W,font=('Helvetica',8),text=ip_dns)
win_cnv.create_text(118,580,anchor=tk.W,font=('Helvetica',8),text='dns.'+dominio)

win_cnv.create_text(273,570,anchor=tk.W,font=('Helvetica',8),text=ip_web)
win_cnv.create_text(273,580,anchor=tk.W,font=('Helvetica',8),text='web.'+dominio)

win_cnv.create_text(436,570,anchor=tk.W,font=('Helvetica',8),text=ip_mail)
win_cnv.create_text(436,580,anchor=tk.W,font=('Helvetica',8),text='mail.'+dominio)

win_cnv.create_text(598,570,anchor=tk.W,font=('Helvetica',8),text=ip_ftp)
win_cnv.create_text(598,580,anchor=tk.W,font=('Helvetica',8),text='ftp.'+dominio)

win_cnv.create_text(752,570,anchor=tk.W,font=('Helvetica',8),text=ip_sql)
win_cnv.create_text(752,580,anchor=tk.W,font=('Helvetica',8),text='sql.'+dominio)

win_cnv.create_text(638,215,anchor=tk.W,font=('Helvetica',8),text=ip_notebook)

win_cnv.create_text(737,109,anchor=tk.W,font=('Helvetica',8),text=so)
win_cnv.create_text(814,215,anchor=tk.W,font=('Helvetica',8),text=ip_desktop)

win_cnv.create_text(202,420,anchor=tk.W,font=('Helvetica',8),text='http://www.'+dominio)
win_cnv.create_text(363,420,anchor=tk.W,font=('Helvetica',8),text=admin.lower()+'@'+dominio)
win_cnv.create_text(520,420,anchor=tk.W,font=('Helvetica',8),text='ftp://ftp.'+dominio)

####################################################################

def create_tap(ntap):
   os.system('tunctl -t '+ntap+' -u nobody > /dev/null 2> /dev/null')
   os.system('ifconfig '+ntap+' up')

def initial_pkgs_uml(fs):
   tmp_pkgs = []
   os.system('rm -Rf mn/*')
   os.system('mount -o loop fs/'+fs+' mn/')
   os.system('mkdir -p mn/opt/dpkg/')
   i = 0
   while (i < len(uml_pkgs)):
      if (uml_fs[i] == fs):
         j = 0
         host_pkgs = uml_pkgs[i] 
         while (j < len(host_pkgs)):
            k = 0
            fnd = False
            while (k < len(tmp_pkgs)):
               if (host_pkgs[j] == tmp_pkgs[k]):
                  fnd = True
               k = k + 1
            if (not fnd):
               os.system('cp -r /opt/dpkg/'+host_pkgs[j]+'/ mn/opt/dpkg/')
               os.system('cp en/bashrc mn/root/.bashrc')
               os.system('cp en/rc.local mn/etc/rc.local')
               os.system('cp en/rc.conf.pl mn/opt/')
               os.system('cp en/bash.conf.pl mn/opt/') 
               os.system('cp -r en/dn/* mn/opt/ 2> /dev/null')
               tmp_pkgs.append(host_pkgs[j])
            j = j + 1
      i = i + 1
   os.system('umount mn/')
   os.system('rm -Rf mn/*')

def initial_uml():
   exit_uml()
   tmp_fs = []
   os.system('rm -Rf en/* 2> /dev/null')
   os.system('mkdir en/dn')
   os.system('cp cf/bashrc en/')
   os.system('cp cf/rc.local en/')
   os.system('cp cf/rc.conf.pl en/')
   os.system('cp cf/bash.conf.pl en/')
   rcconf = open('en/rc.conf.pl','a')
   bashconf = open('en/bash.conf.pl','a')
   i = 0
   while (i < len(uml_name)):
      # ---  por fazer
      os.system('cp -r av/'+uml_name[i]+' en/dn/ 2> /dev/null');
      # ---   / por fazer
      host_eths = uml_eths[i]
      host_macs = uml_macs[i]
      host_ips = uml_ips[i]
      host_masks = uml_masks[i]
      host_pkgs = uml_pkgs[i]
      rcconf.write('### Configuracao do '+uml_name[i]+':\n')
      bashconf.write('### Configuracao do '+uml_name[i]+':\n')
      rcconf.write('my $mac = &catch_mac("eth0");\n')
      bashconf.write('my $hostname = &catch_hostname();\n')
      rcconf.write('if ($mac eq "'+host_macs[0]+'") {\n')
      bashconf.write('if ($hostname eq "'+uml_name[i]+'") {\n')
      if(uml_runrc[i]):
         rcconf.write('   system("/usr/bin/perl /opt/'+uml_name[i]+'/rc_ini.pl 2> /dev/null");\n')
         rcconf.write('   &change_hostname("'+uml_name[i]+'");\n')
         j = 0
         while (j < len(host_ips)):
            rcconf.write('   &network_conf("'+host_eths[j]+'","'+host_ips[j]+'","'+host_masks[j]+'");\n')
            j = j + 1 
         rcconf.write('   &gateway_conf("'+uml_gw[i]+'");\n') 
         rcconf.write('   &nameserver_conf("'+uml_dns[i]+'","'+uml_domain[i]+'");\n') 
         if (uml_route[i]):
            rcconf.write('   &route_enable;\n')
         rcconf.write('   system("/usr/bin/perl /opt/'+uml_name[i]+'/rc_fin.pl 2> /dev/null");\n')
      bashconf.write('   system("/usr/bin/perl /opt/'+uml_name[i]+'/bash_ini.pl 2> /dev/null");\n')
      if (uml_inst[i]):
         j = 0
         while (j < len(host_pkgs)):
            bashconf.write('   &install_pkg("'+host_pkgs[j]+'");\n') 
            j = j + 1 
      bashconf.write('   system("/usr/bin/perl /opt/'+uml_name[i]+'/bash_fin.pl 2> /dev/null");\n')
      rcconf.write('}\n')
      bashconf.write('}\n')
      rcconf.write('#-x-x-x-x-x\n\n')
      bashconf.write('#-x-x-x-x-x\n\n')
      # Comandos (NEW) #########
      host_cmds = uml_cmds[i]
      j = 0
      while (j < len(host_cmds)):
         os.system(host_cmds[j])
         j = j + 1
      ########################## 
      i = i + 1
   rcconf.close() 
   bashconf.close() 
   i = 0
   while (i < len(uml_fs)):
      j = 0
      fnd = False
      while (j < len(tmp_fs) and not fnd):
         if (uml_fs[i] == tmp_fs[j]):
            fnd = True
         j = j + 1
      if (not fnd):
         os.system('cp /opt/filesystem/'+uml_fs[i]+' fs/')
         tmp_fs.append(uml_fs[i])
         initial_pkgs_uml(uml_fs[i])
      i = i + 1

def kill_switch(i):
   os.system('kill $(ps aux | grep \'fdb.show '+switch_name[i]+'\' | awk \'{print $2}\')')
   
def delete_switch(i):
   # nao deletar taps
   os.system('ovs-vsctl del-br '+switch_name[i]+' 2> /dev/null ')

def kill_uml(i):
   os.system('kill $(ps aux | grep \'ubd0=fs/'+uml_name[i]+',fs/'+uml_fs[i]+' \' | awk \'{print $2}\')')
  
def kill_vbox(i):
   os.system('vboxmanage controlvm '+vbox_name[i]+' poweroff 2> /dev/null')

def delete_vbox(i):
   os.system('vboxmanage unregistervm '+vbox_name[i]+' --delete 2> /dev/null')

def kill_wshark(i):
   os.system('kill $(ps aux | grep \'.o wsharkname:'+wshark_name[i]+'\' | awk \'{print $2}\')')

def exit_switch():
   i = 0
   while (i < len(switch_name)):
      kill_switch(i)
      delete_switch(i)
      i = i + 1 

def exit_uml():
   os.system('killall linux_v4 2> /dev/null')
   os.system('killall linux_v4_nf 2> /dev/null')
   os.system('killall linux_v4_nf_b 2> /dev/null')
   os.system('killall linux_v4_nf_c 2> /dev/null')
   os.system('killall linux_v6 2> /dev/null')
   os.system('killall linux_v6_nf 2> /dev/null')
   os.system('killall linux_v6_nf_b 2> /dev/null')
   os.system('killall linux_v6_nf_c 2> /dev/null')
   os.system('rm -Rf fs/*')
   os.system('rm -Rf en/*')

def exit_vbox():
   i = 0
   while (i < len(vbox_name)):
      kill_vbox(i)
      delete_vbox(i)
      i = i + 1 

def exit_wshark():
   i = 0
   while (i < len(wshark_name)):
      kill_wshark(i)
      i = i + 1 

def prep_switch(i):
   win_cnv.itemconfig(rect_c_switch[i],fill=win_rcd)
   win_cnv.itemconfig(rect_e_switch[i],fill=win_red)
   win_cnv.update_idletasks()
   kill_switch(i)
   delete_switch(i)
   os.system('ovs-vsctl add-br '+switch_name[i]+' ')
   swnic_tap = switch_taps[i]
   j = 0
   while (j < len(swnic_tap)):
      create_tap(swnic_tap[j])
      os.system('ovs-vsctl add-port '+switch_name[i]+' '+swnic_tap[j]+' 2>/dev/null ')
      j = j + 1
   os.system('sleep 1')
   win_cnv.itemconfig(rect_c_switch[i],fill=win_rce)
   win_cnv.itemconfig(rect_e_switch[i],fill=win_ree)

def prep_uml(i):
   win_cnv.itemconfig(rect_c_uml[i],fill=win_rcd)
   win_cnv.itemconfig(rect_e_uml[i],fill=win_red)
   win_cnv.update_idletasks()
   kill_uml(i)
   os.system('rm fs/'+uml_name[i]+' 2> /dev/null')
   os.system('sleep 1')
   win_cnv.itemconfig(rect_c_uml[i],fill=win_rce)
   win_cnv.itemconfig(rect_e_uml[i],fill=win_ree)

def prep_vbox(i):
   win_cnv.itemconfig(rect_c_vbox[i],fill=win_rcd)
   win_cnv.itemconfig(rect_e_vbox[i],fill=win_red)
   win_cnv.update_idletasks()
   kill_vbox(i)
   delete_vbox(i)
   os.system('vboxmanage import /opt/vbox/'+vbox_appl[i]+'.ova > /dev/null 2> /dev/null')
   os.system('vboxmanage modifyvm '+vbox_appl[i]+' --name '+vbox_name[i]+' 2> /dev/null')
   win_cnv.itemconfig(rect_c_vbox[i],fill=win_rce)
   win_cnv.itemconfig(rect_e_vbox[i],fill=win_ree)

def prep_wshark(i):
   win_cnv.itemconfig(rect_c_wshark[i],fill=win_rcd)
   win_cnv.itemconfig(rect_e_wshark[i],fill=win_red)
   win_cnv.update_idletasks()
   kill_wshark(i)
   os.system('sleep 1')
   win_cnv.itemconfig(rect_c_wshark[i],fill=win_rce)
   win_cnv.itemconfig(rect_e_wshark[i],fill=win_ree)

def run_switch(i):
   if (win_cnv.itemcget(rect_e_switch[i],'fill') == win_ree):
      kill_switch(i)
      exec_switch = 'ovs-appctl fdb/show '+switch_name[i]+' '
      os.system('xfce4-terminal --disable-server -T '+switch_name[i]+' -x watch --interval 1 "'+exec_switch+'" 2> /dev/null &')

def run_uml(i):
   if (win_cnv.itemcget(rect_e_uml[i],'fill') == win_ree):
      kill_uml(i)
      exec_uml = '/opt/kernel/'+uml_kernel[i]+' ubd0=fs/'+uml_name[i]+',fs/'+uml_fs[i]+' mem='+uml_mem[i]+'M '
      host_eths = uml_eths[i]
      host_taps = uml_taps[i]
      host_macs = uml_macs[i]
      j = 0
      exec_iface = ''
      while (j < len(host_eths)):
         # create_tap(host_taps[j]) # analisar
         exec_iface = host_eths[j]+'=tuntap,'+host_taps[j]+','+host_macs[j]+', '
         exec_uml = exec_uml + exec_iface
         j = j + 1
      os.system('xfce4-terminal --disable-server -T '+uml_name[i]+' -x '+exec_uml+' 2> /dev/null &')

def run_vbox(i):
   if (win_cnv.itemcget(rect_e_vbox[i],'fill') == win_ree):
      kill_vbox(i)
      os.system('vboxmanage modifyvm '+vbox_name[i]+' --vrdeaddress 127.0.0.1 --vrde on --vrdeport '+vbox_rdp[i]+' 2> /dev/null')
      # create_tap(vbox_tap[i]) # analisar
      os.system('vboxmanage modifyvm '+vbox_name[i]+' --bridgeadapter1 '+vbox_tap[i]+' 2> /dev/null')
      macaddress = vbox_mac[i].replace(':','')
      os.system('vboxmanage modifyvm '+vbox_name[i]+' --macaddress1 "'+macaddress+'" 2> /dev/null')
      os.system('vboxmanage startvm '+vbox_name[i]+' --type headless > /dev/null 2> /dev/null')
      os.system('rdesktop -T '+vbox_name[i]+' 127.0.0.1:'+vbox_rdp[i]+' 2> /dev/null &')

def run_wshark(i):
   if (win_cnv.itemcget(rect_e_wshark[i],'fill') == win_ree):
      kill_wshark(i)
      os.system('wireshark -i '+wshark_iface[i]+' -n -k -o wsharkname:'+wshark_name[i]+' &')

def draw_rect (rect_c,rect_e,x,y):
   wd = 2
   y2 = y + win_rsz + wd * 2
   rect_c.append(win_cnv.create_rectangle(x,y,x+win_rsz,y+win_rsz,fill=win_rcd,width=wd))
   rect_e.append(win_cnv.create_rectangle(x,y2,x+win_rsz,y2+win_rsz,fill=win_red,width=wd))

def draw_rect_all():
   i = 0
   while (i < len(switch_rect_x)):
      draw_rect(rect_c_switch,rect_e_switch,switch_rect_x[i],switch_rect_y[i])
      i = i + 1
   i = 0
   while (i < len(uml_rect_x)):
      draw_rect(rect_c_uml,rect_e_uml,uml_rect_x[i],uml_rect_y[i])
      i = i + 1
   i = 0
   while (i < len(vbox_rect_x)):
      draw_rect(rect_c_vbox,rect_e_vbox,vbox_rect_x[i],vbox_rect_y[i])
      i = i + 1
   i = 0
   while (i < len(wshark_rect_x)):
      draw_rect(rect_c_wshark,rect_e_wshark,wshark_rect_x[i],wshark_rect_y[i])
      i = i + 1

def usr_clic(event):
   x = event.x
   y = event.y
   i = 0
   fnd = False
   while (i < len(switch_name) and not fnd):
      [xmin,ymin,xmax,ymax] = win_cnv.coords(rect_c_switch[i])
      if (xmin <= x <= xmax and ymin <= y <= ymax):
         prep_switch(i)
         fnd = True
      [xmin,ymin,xmax,ymax] = win_cnv.coords(rect_e_switch[i])
      if (xmin <= x <= xmax and ymin <= y <= ymax):
         run_switch(i)
         fnd = True
      i = i + 1
   i = 0
   fnd = False
   while (i < len(uml_name) and not fnd):
      [xmin,ymin,xmax,ymax] = win_cnv.coords(rect_c_uml[i])
      if (xmin <= x <= xmax and ymin <= y <= ymax):
         prep_uml(i)
         fnd = True
      [xmin,ymin,xmax,ymax] = win_cnv.coords(rect_e_uml[i])
      if (xmin <= x <= xmax and ymin <= y <= ymax):
         run_uml(i)
         fnd = True
      i = i + 1
   i = 0
   while (i < len(vbox_name) and not fnd):
      [xmin,ymin,xmax,ymax] = win_cnv.coords(rect_c_vbox[i])
      if (xmin <= x <= xmax and ymin <= y <= ymax):
         prep_vbox(i)
         fnd = True
      [xmin,ymin,xmax,ymax] = win_cnv.coords(rect_e_vbox[i])
      if (xmin <= x <= xmax and ymin <= y <= ymax):
         run_vbox(i)
         fnd = True
      i = i + 1
   i = 0
   while (i < len(wshark_name) and not fnd):
      [xmin,ymin,xmax,ymax] = win_cnv.coords(rect_c_wshark[i])
      if (xmin <= x <= xmax and ymin <= y <= ymax):
         prep_wshark(i)
         fnd = True
      [xmin,ymin,xmax,ymax] = win_cnv.coords(rect_e_wshark[i])
      if (xmin <= x <= xmax and ymin <= y <= ymax):
         run_wshark(i)
         fnd = True
      i = i + 1

def usr_clic_xy(event):
   x = event.x
   y = event.y
   print('x '+str(x)+' y '+str(y))

def init_preps():
   i = 0 
   while (i < len(switch_name)):
      if (switch_prep[i]):
         prep_switch(i)      
      i = i + 1
   i = 0 
   while (i < len(uml_name)):
      if (uml_prep[i]):
         prep_uml(i)      
      i = i + 1
   i = 0 
   while (i < len(vbox_name)):
      if (vbox_prep[i]):
         prep_vbox(i)      
      i = i + 1
   i = 0 
   while (i < len(wshark_name)):
      if (wshark_prep[i]):
         prep_wshark(i)      
      i = i + 1

def init_loads():
   i = 0 
   while (i < len(switch_name)):
      if (switch_load[i]):
         run_switch(i)      
      i = i + 1
   i = 0 
   while (i < len(uml_name)):
      if (uml_load[i]):
         run_uml(i)      
      i = i + 1
   i = 0 
   while (i < len(vbox_name)):
      if (vbox_load[i]):
         run_vbox(i)      
      i = i + 1
   i = 0 
   while (i < len(wshark_name)):
      if (wshark_load[i]):
         run_wshark(i)      
      i = i + 1

####################################################################

initial_uml()
draw_rect_all()
init_preps()
init_loads()

#### Mirror Port
os.system("sudo ovs-vsctl clear bridge switch-dmz mirrors");
os.system("ovs-vsctl -- set Bridge switch-dmz mirrors=@m -- --id=@tap10 get Port tap10 -- --id=@tap16 get Port tap16 -- --id=@m create Mirror name=mirror1 select-dst-port=@tap10 select-src-port=@tap10 output-port=@tap16 > /dev/null");

win_cnv.bind('<Double-1>',usr_clic)
win_cnv.bind('<Double-3>',usr_clic_xy)
win.mainloop()

exit_wshark()
exit_uml()
exit_vbox()
exit_switch()


####################################################################


