#!/usr/bin/perl

use strict;

my $pass = crypt("_senhaadmin_","password");
system("useradd -m -p $pass _nomeadmin_ -s /bin/bash");
system("passwd -d estudante");

# Possivel Bug - Resolver!
system("dpkg --install /opt/sql/mysql-server/*");
#system("( ( sleep 60 ) \&\& dpkg --install /opt/sql/mysql-server/* \& )");
system("echo \"\#!/bin/sh\ndpkg --install /opt/sql/mysql-server/*\nmysql -u root < /opt/sql/opt/app.dump\nsed -i 's/127.0.0.1/0.0.0.0/g' /etc/mysql/my.cnf\n/etc/init.d/mysql restart\n\" > /root/install_mysql.sh");

