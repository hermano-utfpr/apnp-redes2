#!/usr/bin/perl

use strict;

my $srv = 'web';

system("cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.old");
system("cp -R /opt/$srv/var/www/html/* /var/www/html/");
system("cp /opt/$srv/etc/apache2/sites-available/* /etc/apache2/sites-available/");
system("a2dismod deflate -f");
system("/etc/init.d/apache2 restart");

my $pass = crypt("_senhaadmin_","password");
system("useradd -m -p $pass _nomeadmin_ -s /bin/bash");
system("passwd -d estudante");


