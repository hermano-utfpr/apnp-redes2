<?php

header("Location: view.php");

?>
