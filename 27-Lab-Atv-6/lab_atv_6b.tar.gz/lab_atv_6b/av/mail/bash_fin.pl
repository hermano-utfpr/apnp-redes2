#!/usr/bin/perl

use strict;

my $srv = 'mail';

system("cp /etc/postfix/main.cf /etc/postfix/main.cf.old");
system("cp /opt/$srv/etc/postfix/* /etc/postfix/");
system("/etc/init.d/postfix restart");

my $pass = crypt("_senhaadmin_","password");
system("useradd -m -p $pass _nomeadmin_ -s /bin/bash");
system("su - _nomeadmin_ -c \"maildirmake Maildir\"");
system("passwd -d estudante");


system("mail -s \"Seja bem-vindo(a)\" _nomeadmin_\@_seldominio_ < /opt/$srv/welcome.txt");

