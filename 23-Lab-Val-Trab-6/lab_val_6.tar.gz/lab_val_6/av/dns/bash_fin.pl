#!/usr/bin/perl

use strict;

my $srv = "dns";

system("cp /opt/$srv/etc/dhcp/dhcpd.conf /etc/dhcp/");
system("/etc/init.d/isc-dhcp-server restart");

system("cp /opt/$srv/etc/bind/* /etc/bind/");
system("cp /opt/$srv/var/cache/bind/* /var/cache/bind/");
system("/etc/init.d/bind9 restart");


