#!/usr/bin/perl

use strict;

my $srv = "mail";

system("cp /opt/$srv/etc/postfix/* /etc/postfix/");
system("/etc/init.d/postfix restart");

my $pass = crypt("abc123","password");
system("useradd -m -p $pass contato");
system("su - contato -c \"maildirmake Maildir\"");

