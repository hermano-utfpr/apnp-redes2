#!/usr/bin/perl

system("dpkg --install /opt/web/pkg/*.deb");

system("cp /opt/web/var/www/html/* /var/www/html/");
system("/etc/init.d/apache2 restart");


my $pass = crypt("abc123","password");
system("useradd -m -p $pass webdesigner");


