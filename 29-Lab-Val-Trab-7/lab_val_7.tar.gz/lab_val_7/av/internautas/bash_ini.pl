#!/usr/bin/perl

system("dpkg --install /opt/internautas/pkg/libnet-telnet-perl_3.04-1_all.deb");

