#!/usr/bin/perl

use strict;

use strict;
use Net::Telnet;

my $gateway = "_ipgw_";

my $usr = 0;

my $rede = "_iprede_";

my @ips;
my $b = 50;
for (my $i = 0; $i <= 5; $i++) {
   my $b4 = int(rand(20)+$b); 
   if (!($b4 % 2 == 0)) {
      $b4--;
   }
   $ips[$i] = $rede.".".$b4;
   $b += 20;
}

system("clear");

while (1) {

   $usr++;

   system("ifconfig eth0 ".$ips[$usr-1]." ");
   system("route add default gw $gateway");

   print ("---Internauta $usr: ----------------------------------------------------\n");

   print ("- Vou acessar www._dominio_ ...\n");

   system("rm /tmp/saida.txt 2> /dev/null");
   system("wget --timeout=5 --tries=1 http://www._dominio_ -O /tmp/saida.txt 2> /dev/null");
   my $encontrou = 0;
   open (SAIDA, "/tmp/saida.txt");
   while (my $l = <SAIDA>) {
      if ($l =~ /_dominio_/i) {
         $encontrou = 1;
      }
   } 
   close (SAIDA);  

   if ($encontrou) {
      print ("- Acessei o site normalmente!                                  $usr  :)\n");
   } else {
      print ("- O site está com problemas?!                                  $usr  :(\n");
   }

   sleep(2);
   
   $usr++;

   system("ifconfig eth0 ".$ips[$usr-1]." ");
   system("route add default gw $gateway");

   print ("---Internauta $usr: ----------------------------------------------------\n");

   print ("- Vou mandar um e-mail para contato\@_dominio_ ...\n");

   my @nomes = ("adalgiza","bernardo","carolina","diogo","eduardo","fabiana","gabriela","heloisa","joana","katia","luciano","marcos","nivaldo","osvaldo","patricia","roberto","sandra","tatiana","valmir","wesley","zeni");
   my $rn = int(rand(scalar(@nomes)));
   my @dominios = ("gmail.com","hotmail.com","yahoo.com","ig.com.br","bol.com.br","outlook.com");
   my $rd = int(rand(scalar(@dominios)));
   my @palavras = ("Livro As Cronicas de Narnia","Livro Harry Potter","Livro Sherlok Holmes","Jogo Final Fantasy","Jogo Fifa 16","Jogo Gears of War 4","DVD Star Wars","DVD Doctor Who","DVD X-Men");
   my $rp = int(rand(scalar(@palavras)));

   my $nomecontato = ucfirst($nomes[$rn]);
   my $mailcontato = $nomes[$rn]."\@".$dominios[$rd];
   my $assunto = $palavras[$rp];

   my $falhas = 0;
   my $t;
   
   eval {
      my $t = new Net::Telnet (Timeout => 5, Host => 'mail._dominio_', Port => 25, Prompt => '/./') or $falhas = 1;
      $t->open() or $falhas = 1;
      my $cmd = "ehlo _dominio_\n";
      $cmd .= "mail from: $mailcontato\n";
      $cmd .= "rcpt to: contato\@_dominio_\n";
      $cmd .= "data\n";
      $cmd .= "From: $mailcontato\n";
      $cmd .= "To: contato\@_dominio_\n";
      $cmd .= "Subject: Sobre o $assunto!\n\n";
      $cmd .= "Ola Senhores(as),\n\n";
      $cmd .= "Gostaria de saber sobre o $assunto!\n";
      $cmd .= "A loja esta em funcionamento?\n\n";
      $cmd .= "Agradeco :)\n\n";
      $cmd .= "$nomecontato\n";
      $cmd .= "\n\n.\n\nquit\n\n";
      $t->cmd($cmd) or $falhas = 1;
      $t->close;
   } or do {
      $falhas = 1;
   };

   if ($falhas == 0) {
      print ("- Enviei um e-mail normalmente!                                $usr  :)\n");
   } else {
      print ("- Não consegui enviar o e-mail!                                $usr  :(\n");
   }

   sleep(2);

   if ($usr >= 6) {
      $usr = 0;
   }

}
