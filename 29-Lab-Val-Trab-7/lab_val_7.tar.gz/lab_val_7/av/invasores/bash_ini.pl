#!/usr/bin/perl

system("dpkg --install /opt/invasores/pkg/*.deb");

