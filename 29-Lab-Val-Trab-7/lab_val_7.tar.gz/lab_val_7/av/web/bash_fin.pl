#!/usr/bin/perl

use strict;

my $srv = 'web';

system("mkdir /srv/tftp/");
system("chmod 777 /srv/tftp/");
system("rm -Rf /var/www/html/");
system("ln -sf /srv/tftp/ /var/www/html");
system("cp /opt/$srv/var/www/html/* /var/www/html/");
system("chmod 777 /srv/tftp/*");
system("a2dismod deflate -f");
system("/etc/init.d/apache2 restart");

my $pass = crypt("_senhaadmin_","password");
system("useradd -m -p $pass _nomeadmin_ -s /bin/bash");
system("passwd -d estudante");


