#!/usr/bin/perl

# use numeros pares
# perl dominio.com 2 outro.com 4 aindaoutro.com 6

open (ARQ, ">db.com");
print ARQ "\$ORIGIN com.\n";
print ARQ "\$TTL 10;\n";
print ARQ "\@ IN SOA root root (1 10 10 10 10);\n";
print ARQ "\@ IN NS root\n";
print ARQ "root IN A 200.0.254.10\n\n";
for ($i = 0; $i < scalar(@ARGV); $i += 2) {
   print ARQ $ARGV[$i]." IN NS dns.".$ARGV[$i]."\n";
   print ARQ "dns.".$ARGV[$i]." IN A 200.0.".$ARGV[$i+1].".10\n\n";
}
close (ARQ);

open (ARQ, ">db.0.200");
print ARQ "\$ORIGIN 0.200.in-addr.arpa.\n";
print ARQ "\$TTL 10;\n";
print ARQ "\@ IN SOA root.com. root.com. (1 10 10 10 10);\n";
print ARQ "\@ IN NS root.com.\n\n";
for ($i = 0; $i < scalar(@ARGV); $i += 2) {
   print ARQ $ARGV[$i+1]." IN NS dns.".$ARGV[$i].".com.\n";
   print ARQ ($ARGV[$i+1]+1)." IN NS dns.".$ARGV[$i].".com.\n";
}
close (ARQ);

for ($i = 0; $i < scalar(@ARGV); $i += 2) {
   print $ARGV[$i+1]." -> ".$ARGV[$i]."\n";
}


