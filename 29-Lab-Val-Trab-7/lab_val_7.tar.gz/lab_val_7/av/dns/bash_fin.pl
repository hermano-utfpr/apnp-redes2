#!/usr/bin/perl

use strict;

my $srv = "dns";

system("cp /opt/$srv/etc/bind/* /etc/bind/");
system("cp /opt/$srv/var/cache/bind/* /var/cache/bind/");
system("/etc/init.d/bind9 restart");

my $pass = crypt("_senhaadmin_","password");
system("useradd -m -p $pass _nomeadmin_ -s /bin/bash");
system("passwd -d estudante");


