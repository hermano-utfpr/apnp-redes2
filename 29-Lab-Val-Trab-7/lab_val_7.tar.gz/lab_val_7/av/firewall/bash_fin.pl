#!/usr/bin/perl

use strict;

my $srv = "firewall";

system("cp /opt/$srv/etc/dhcp/dhcpd.conf /etc/dhcp/");
system("/etc/init.d/isc-dhcp-server restart");


